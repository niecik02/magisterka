<?php

use Illuminate\Database\Seeder;
use App\Pages;

class PAgesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	/*for($i=0;$i<10;$i++)
    	{
	    	$faker=\Faker\Factory::create();
	        $page=new Pages();
	        $page->title=$faker->company;
	        $page->save();
           /$page->Autorzy()->attach(1);
            $page->Recenzenci()->attach(3);
    	}*/
    }
}
