<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AutorzyArtykulow extends Model
{
    protected $fillable=[
        'users_id','pages_id'
    ];
}
