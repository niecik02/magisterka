<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dataRecenzji extends Model
{
    protected $fillable=[
        'pages_id','data'
    ];
}
