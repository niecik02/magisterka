@extends('layouts.app')
@section('nav')
    <li><a href="{{route('autor.index')}}">Moje Artykuły</a></li>
    <li><a href="{{route('autor.create')}}">Dodaj Artykuł</a></li>
@endsection



