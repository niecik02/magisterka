@extends('layouts.app')
@section('nav')
    <li><a href="{{route('recenzent.index')}}">Moje Recenzje</a></li>
@endsection


