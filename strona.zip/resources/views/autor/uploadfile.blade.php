@extends('layouts.autor')
@section('title') Plik dodany @endsection
@section('content')

    <h1>Pomyślnie dodano pliki</h1>

@endsection