@extends('emails.layouts')

@section('content')

<h1>Praca o tytule: "{{$page->title}}", została zaakceptowana.</h1>



Wiadomość generowana automatycznie, prosimy na nią nie odpowiadać!!!

@endsection
