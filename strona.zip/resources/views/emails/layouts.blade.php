<html lang="pl-PL">
<head>
</head>
<body>

<div class="container">
    <div class="content">
        @yield('content')

    </div>
</div>

</body>