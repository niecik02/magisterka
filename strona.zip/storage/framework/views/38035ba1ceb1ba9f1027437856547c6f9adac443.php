<?php $__env->startSection('title'); ?> <?php echo e($page->title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="naglowek">Tytuł</div><div class="tekst"><?php echo e($page->title); ?></div>
    <div class="naglowek">
        Pliki:
        <button type="button" class="btn btn-default" data-toggle="modal" data-placement="bottom" data-target="#edit_1plik" title="Edytuj Pliki">
            <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
        </button>
    </div>
    <?php if(isset($page->plik_miz)): ?>
        <div class="row">
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_miz)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik miz</span> </a>
            </div>
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_bib)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik bib</span> </a>
            </div>
            <?php if(isset($page->plik_voc)): ?>
                <div class="col-xs-3 col-md-3">
                    <a class="pobierz" href= <?php echo e(asset($page->plik_voc)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik voc</span></a>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="tekst">Brak plików do pobrania</div>
    <?php endif; ?>




    <br>
    <?php if($komentarze!='[]'): ?>
        <div class="tekst">
            <div class="panel panel-primary">
                <div class="panel-heading" role="tab" id="headingOne">
                    <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#wiadomości" aria-expanded="false" aria-controls="wiadomości">
                        <h4 class="panel-title">
                            Wiadomości <span class="caret"></span>
                        </h4>
                    </a>
                </div>
                <div id="wiadomości" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <div class="navbar-right" style="margin-right: 20px; margin-top: 10px">
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#odpowiedz">
                        Odpowiedz
                    </button>
                    </div>
                    <?php $__currentLoopData = $komentarze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentarz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="panel-body">
                            <div class="naglowek">
                                <?php if($komentarz->status==2): ?>
                                    <span class="glyphicon glyphicon-user">
                                    Edytor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php else: ?>
                                    <span class="glyphicon glyphicon-user">
                                    Autor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#odpowiedz">
            Odpowiedz
        </button>
    <?php endif; ?>






    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <div class="tekst">
            Recenzenci:
            <?php if(isset($data)): ?>
                <?php $__currentLoopData = $ilu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jeden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($jeden->status!=3): ?>
                        <div class="panel panel-info">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($jeden->id); ?>" aria-expanded="false" aria-controls="<?php echo e($jeden->id); ?>">
                                    <h4 class="panel-title">
                                        <?php echo e($jeden->name); ?> <span class="caret"></span>
                                    </h4>
                                </a>
                            </div>
                            <div id="<?php echo e($jeden->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body">
                                    <?php $a=0 ?>
                                    <?php $__currentLoopData = $recenzenci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($recenzent->users_id==$jeden->users_id): ?>
                                            <?php switch($recenzent->status):
                                            case (1): ?>
                                            <h5 class="panel-title"> Oczekuje na akceptacje</h5>
                                            <?php break; ?>
                                            <?php case (2): ?>
                                            <?php if($recenzent->recenzja_id==NULL): ?>
                                                <h5 class="panel-title"> Brak recenzji</h5>
                                                <?php $a++; ?>
                                            <?php endif; ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $recenzje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($recenzent->recenzja_id==$recenzja->pivot->recenzja_id): ?>
                                                    <?php if($a==0): ?>
                                                        <h5><b>Confidence:</b> <?php echo e($recenzja->confidence); ?></h5>
                                                        <h5><b>Decision:</b> <?php echo e($recenzja->decision); ?></h5>
                                                        <h5><b>Presentation:</b> <?php echo e($recenzja->presentation); ?></h5>
                                                        <h5><b>Quality of formalization:</b> <?php echo e($recenzja->quality_of_formalization); ?></h5>
                                                        <h5><b>Significance for mml:</b> <?php echo e($recenzja->significance_for_mml); ?></h5>
                                                        <h5><b>Comments:</b> <?php echo e($recenzja->comments); ?></h5>
                                                        <h5><b>Mml remarks:</b> <?php echo e($recenzja->mml_remarks); ?></h5><br/>
                                                        <?php $a++ ?>
                                                    <?php else: ?>
                                                        <h5><b><a href="#" onclick="op('#<?php echo e($recenzja->id); ?>')">Poprzednia recenzja:  <span class="glyphicon glyphicon-chevron-down"></span> </a></b></h5>
                                                        <div id="<?php echo e($recenzja->id); ?>" style="display:none;">
                                                            <h5><b>Confidence:</b> <?php echo e($recenzja->confidence); ?></h5>
                                                            <h5><b>Decision:</b> <?php echo e($recenzja->decision); ?></h5>
                                                            <h5><b>Presentation:</b> <?php echo e($recenzja->presentation); ?></h5>
                                                            <h5><b>Quality of formalization:</b> <?php echo e($recenzja->quality_of_formalization); ?></h5>
                                                            <h5><b>Significance for mml:</b> <?php echo e($recenzja->significance_for_mml); ?></h5>
                                                            <h5><b>Comments:</b> <?php echo e($recenzja->comments); ?></h5>
                                                            <h5><b>Mml remarks:</b> <?php echo e($recenzja->mml_remarks); ?></h5>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <h5 class="panel-title"> Brak recenzji</h5>
                                            <?php endif; ?>
                                            <?php break; ?>
                                            <?php endswitch; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Brak Recezentów
            <?php endif; ?>
        </div>
    </div>
    <!-- Modal -->
    <div id="edit_1plik" class="modal fade" role="dialog">
        <div class="modal-dialog">
        <?php echo Form::open(['route'=>['autor.update',$page],'method'=>'PUT','onSubmit'=>"return sprawdz_form(this)", 'files'=>true]); ?>

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Zmień pliki</h4>
                </div>
                <div class="modal-body">
                    <?php echo Form::label ('plik_miz','Wybierz plik .miz do wyslania'); ?>


                    <?php echo Form::file('plik_miz'); ?>



                    <?php echo Form::label ('plik_bib','Wybierz plik .bib do wyslania'); ?>


                    <?php echo Form::file('plik_bib'); ?>


                    <?php echo Form::label ('plik_voc','Wybierz plik .voc do wyslania'); ?>


                    <?php echo Form::file('plik_voc'); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>
                    <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary','onClick'=>'return sprawdz()']); ?>

                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    <div id="odpowiedz" class="modal fade" role="dialog">
        <div class="modal-dialog">
        <?php echo Form::model($page,['route'=>['autor.odpowiedz',$page],'method'=>'PUT','onSubmit'=>"return sprawdz_form(this)"]); ?>

        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Odpowiedz</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <?php echo Form::label('komentarz',"Komentarz:"); ?>

                        <?php echo Form::textarea('komentarz',null,['class'=>'form-control', 'placeholder'=>'Dodaj komentarz...']); ?>

                        <div class="error"></div>
                    </div>
                </div>
                <div class="modal-footer ">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>
                    <?php echo Form::submit('Wyślij',['class'=>'btn btn-primary']); ?>

                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>