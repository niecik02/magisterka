<?php $__env->startSection('content'); ?>

<h1>Praca o tytule: "<?php echo e($page->title); ?>", została zaakceptowana.</h1>



Wiadomość generowana automatycznie, prosimy na nią nie odpowiadać!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>