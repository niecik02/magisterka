<?php $__env->startSection('content'); ?>
    <h1>Zostałeś Recenzentem </h1>

    <h3>Zostaleś recenzentem pracy o tytule:<?php echo e($page->title); ?></h3>
    <h4>Ostateczny temin oddania recenzji:  </h4>


    Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>