<?php $__env->startSection('title'); ?> <?php echo e($page->title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="naglowek">Tytuł</div><div class="tekst"><?php echo e($page->title); ?></div>

    <div class="naglowek"> Pliki:</div>
    <?php if(isset($page->plik_miz)): ?>
        <div class="row">
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_miz)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik miz</span> </a>
            </div>
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_bib)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik bib</span> </a>
            </div>
            <?php if(isset($page->plik_voc)): ?>
                <div class="col-xs-3 col-md-3">
                    <a class="pobierz" href= <?php echo e(asset($page->plik_voc)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik voc</span></a>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="tekst">Brak plików do pobrania</div>
    <?php endif; ?>
    <?php if($komentarze!='[]'): ?>
        <div class="tekst">
            <div class="panel panel-primary">
                <div class="panel-heading" role="tab" id="headingOne">
                    <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#wiadomości" aria-expanded="false" aria-controls="wiadomości">
                        <h4 class="panel-title">
                            Wiadomości <span class="caret"></span>
                        </h4>
                    </a>
                </div>
                <div id="wiadomości" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <?php $__currentLoopData = $komentarze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentarz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="panel-body">
                            <div class="naglowek">
                                <?php if($komentarz->status==2): ?>
                                    <span class="glyphicon glyphicon-user">
                                    Edytor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php else: ?>
                                    <span class="glyphicon glyphicon-user">
                                    Autor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="tekst">Ostateczny termin oddania recenzji:<?php if(isset($data)): ?> <?php echo e($data->data); ?><?php else: ?> brak wyznaczonej daty <?php endif; ?></div>


    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <div class="tekst">
            Recenzent:
            <?php if(isset($data)): ?>
                <?php $a=1?>
                <?php $__currentLoopData = $ilu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jeden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($jeden->status!=3): ?>
                        <div class="panel panel-info">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($jeden->id); ?>" aria-expanded="false" aria-controls="<?php echo e($jeden->id); ?>">
                                    <h4 class="panel-title">
                                        Recenzent<?php echo e($a); ?> <span class="caret"></span>
                                    </h4>
                                </a>
                            </div>
                            <div id="<?php echo e($jeden->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body">
                                    <?php $a=0 ?>
                                    <?php $__currentLoopData = $recenzenci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($recenzent->users_id==$jeden->users_id): ?>
                                            <?php switch($recenzent->status):
                                            case (1): ?>
                                            <h5 class="panel-title"> Oczekuje na akceptacje</h5>
                                            <?php break; ?>
                                            <?php case (2): ?>
                                            <?php if($recenzent->recenzja_id==NULL): ?>
                                                <h5 class="panel-title"> Brak recenzji</h5>
                                                <?php $a++; ?>
                                            <?php endif; ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $recenzje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($recenzent->recenzja_id==$recenzja->pivot->recenzja_id): ?>
                                                    <?php if($a==0): ?>
                                                        <h5><b>Confidence:</b> <?php echo e($recenzja->confidence); ?></h5>
                                                        <h5><b>Decision:</b> <?php echo e($recenzja->decision); ?></h5>
                                                        <h5><b>Presentation:</b> <?php echo e($recenzja->presentation); ?></h5>
                                                        <h5><b>Quality of formalization:</b> <?php echo e($recenzja->quality_of_formalization); ?></h5>
                                                        <h5><b>Significance for mml:</b> <?php echo e($recenzja->significance_for_mml); ?></h5>
                                                        <h5><b>Comments:</b> <?php echo e($recenzja->comments); ?></h5>
                                                        <h5><b>Mml remarks:</b> <?php echo e($recenzja->mml_remarks); ?></h5><br/>
                                                        <?php $a++ ?>
                                                    <?php else: ?>
                                                        <h5><b><a href="#" onclick="op('#<?php echo e($recenzja->id); ?>')">Poprzednia recenzja:  <span class="glyphicon glyphicon-chevron-down"></span> </a></b></h5>
                                                        <div id="<?php echo e($recenzja->id); ?>" style="display:none;">
                                                            <h5><b>Confidence:</b> <?php echo e($recenzja->confidence); ?></h5>
                                                            <h5><b>Decision:</b> <?php echo e($recenzja->decision); ?></h5>
                                                            <h5><b>Presentation:</b> <?php echo e($recenzja->presentation); ?></h5>
                                                            <h5><b>Quality of formalization:</b> <?php echo e($recenzja->quality_of_formalization); ?></h5>
                                                            <h5><b>Significance for mml:</b> <?php echo e($recenzja->significance_for_mml); ?></h5>
                                                            <h5><b>Comments:</b> <?php echo e($recenzja->comments); ?></h5>
                                                            <h5><b>Mml remarks:</b> <?php echo e($recenzja->mml_remarks); ?></h5>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <?php endif; ?>
                                            <?php break; ?>
                                            <?php endswitch; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                        <?php $a++?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Brak Recezentów
            <?php endif; ?>
        </div>
    </div>
    <script>
        jQuery(document).ready(function($){
            op = function(obj) {
                $(obj).stop().slideToggle();
            };
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.recenzent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>