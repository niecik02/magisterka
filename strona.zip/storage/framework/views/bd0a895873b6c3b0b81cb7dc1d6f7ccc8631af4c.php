<?php $__env->startSection('content'); ?>
    <h1>Zostałeś Recenzentem </h1>

    <h3>Zostaleś wyznaczony do recenzenzji pracy o tytule:<?php echo e($page->title); ?></h3>
    <h4><a href="<?php echo e(asset('/')); ?>" > Zaloguj się do systemu aby zaakceptować lub odrzucić propozycje recenzji.</a></h4>

    Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>