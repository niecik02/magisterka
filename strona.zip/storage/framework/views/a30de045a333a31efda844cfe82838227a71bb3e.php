<?php $__env->startSection('content'); ?>
<h1>Zostałeś nowym Użytkownikiem</h1>

<h3>Wejdz na strone aby się zalogować:<a href="<?php echo e(asset('/')); ?>" >Link</a></h3>
<h4>Login: <?php echo e($login); ?> </h4>
<h4>Haslo: <?php echo e($haslo); ?></h4>


Wiadomość generowana automatycznie, prosimy na nią nie odpowiadać!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>