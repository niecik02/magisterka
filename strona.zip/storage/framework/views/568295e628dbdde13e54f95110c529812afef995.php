<?php $__env->startSection('content'); ?>
    <h1>Zostala dodana nowa praca!!!</h1>

    <h3>Tytuł:<?php echo e($request->title); ?></h3>

    Zaloguj się aby dodać recenzentów.<br/>
    <b>Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!</b>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>