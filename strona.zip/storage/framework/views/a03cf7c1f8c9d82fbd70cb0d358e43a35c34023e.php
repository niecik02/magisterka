<?php $__env->startSection('title', 'Zmiana ról'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Użytkownicy</h1>
    <div class="tabs">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#Edytorzy">Edytorzy</a></li>
            <li><a href="#Uzytkownicy">Użytkownicy</a></li>


        </ul>


        <div class="tab-content">
            <div id="Edytorzy" class="tab">
                <table class="table table-hover">
                    <tr><th>Imię i Nazwisko</th> <th>Email</th> <th>Opcje</th></tr>
                    <?php $__currentLoopData = $edytorzy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php echo Form::open(['route'=>['uzytkownicy.edit'],'method'=>'POST']); ?>

                                <?php echo Form::hidden('users_id',$user->id); ?>

                                <?php echo Form::hidden('roles_id',2); ?>

                                <?php echo Form::submit('Użytkownik',['class'=>'btn btn-primary']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>


            <div id="Uzytkownicy" class="tab" style="display:none">
                <table class="table table-hover">
                    <tr> <th>Login</th> <th>Email</th> <th>Opcje</th>  </tr>
                    <?php $__currentLoopData = $uzytkownicy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php echo Form::open(['route'=>['uzytkownicy.edit'],'method'=>'POST']); ?>

                                <?php echo Form::hidden('users_id',$user->id); ?>

                                <?php echo Form::hidden('roles_id',1); ?>

                                <?php echo Form::submit('Edytor',['class'=>'btn btn-warning']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>



        </div>
    </div>

    <script>
        jQuery(document).ready(function() {
            jQuery('.tabs .nav-tabs a').on('click', function(e)  {
                var currentAttrValue = jQuery(this).attr('href');

                // Show/Hide Tabs
                jQuery('.tabs ' + currentAttrValue).show().siblings().hide();

                // Change/remove current tab to active
                jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

                e.preventDefault();
            });
        });
    </script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.edytor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>