<?php $__env->startSection('content'); ?>
<h1>Twoja praca do poprawy</h1>

<h3>Praca o tytule: "<?php echo e($page->title); ?>", została przeznaczona do paprawy.</h3>
<h4>Komentarz: <?php echo e($request->komentarz); ?></h4>


Wiadomość generowana automatycznie, prosimy na nią nie odpowiadać!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>