<?php $__env->startSection('content'); ?>
    <h1>Odrzucona Recenzja </h1>

    <h3>Użytkownik: <?php echo e($user->name); ?>, postanowił nie oddawać recenzji do pracy o tytule <?php echo e($title->title); ?></h3><br/>
    <h4><a href="<?php echo e(asset('/')); ?>" > Zaloguj się do systemu aby wprowadzić zmiany.</a></h4><br/>

    Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>