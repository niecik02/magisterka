<?php $__env->startSection('content'); ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Panel</div>

                <div class="panel-body">
                    Zaloguj się jako:
                    <br/>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>


                        </div>

                    <?php endif; ?>
                        <a href="<?php echo e(route('autor.index')); ?>"><button class="btn btn-primary">  Autor </button></a>
                    <?php if($recenzje>0): ?>
                        <a href="<?php echo e(route('recenzent.index')); ?>"><button class="btn btn-primary">Recenzent</button></a>
                    <?php endif; ?>
                    <?php if(Auth::user()->hasRole('edytor')==true): ?>
                        <a href="<?php echo e(route('hello.index')); ?>"><button class="btn btn-primary">Edytor</button></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>