<?php $__env->startSection('content'); ?>
<h1>Praca poprawiona</h1>

<h3>Praca o tytule: "<?php echo e($page->title); ?>", została poprawiona.</h3>
<h4><a href="<?php echo e(asset('/')); ?>" > Zaloguj się do systemu aby zaakceptować prace.</a></h4>


Wiadomość generowana automatycznie, prosimy na nią nie odpowiadać!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>