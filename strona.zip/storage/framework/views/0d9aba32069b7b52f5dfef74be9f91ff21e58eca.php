<?php $__env->startSection('content'); ?>
    <h1>Wszystkie Recenzje!! </h1>

    <h3>Do pracy o tytule: <?php echo e($title->title); ?>, dodano wszystkie recenzje.</h3><br/>
    <h4><a href="<?php echo e(asset('/')); ?>" > Zaloguj się do systemu aby wprowadzić zmiany.</a></h4><br/>

    Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>