<?php $__env->startSection('title'); ?> <?php echo e($page->title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="naglowek">Tytuł:</div><div class="tekst"><?php echo e($page->title); ?></div>
    <div class="naglowek"> Pliki:</div>
    <?php if(isset($page->plik_miz)): ?>
        <div class="row">
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_miz)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik miz</span> </a>
            </div>
            <div class="col-xs-3 col-md-3">
                <a class="pobierz" href= <?php echo e(asset($page->plik_bib)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik bib</span> </a>
            </div>
            <?php if(isset($page->plik_voc)): ?>
                <div class="col-xs-3 col-md-3">
                    <a class="pobierz" href= <?php echo e(asset($page->plik_voc)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik voc</span></a>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="tekst">Brak plików do pobrania</div>
    <?php endif; ?><br/>
    <?php if($komentarze!='[]'): ?>
        <div class="tekst">
            <div class="panel panel-primary">
                <div class="panel-heading" role="tab" id="headingOne">
                    <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#wiadomości" aria-expanded="false" aria-controls="wiadomości">
                        <h4 class="panel-title">
                            Wiadomości <span class="caret"></span>
                        </h4>
                    </a>
                </div>
                <div id="wiadomości" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <?php $__currentLoopData = $komentarze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentarz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="panel-body">
                            <div class="naglowek">
                                <?php if($komentarz->status==2): ?>
                                    <span class="glyphicon glyphicon-user">
                                    Edytor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php else: ?>
                                    <span class="glyphicon glyphicon-user">
                                    Autor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?><br/>

    <div class="tekst"> Ostateczny termin oddania recenzji:<?php if(isset($data)): ?> <?php echo e($data->data); ?><?php else: ?> brak wyznaczonej daty <?php endif; ?></div>
    <br>

    <?php if($id->status==1): ?>

        <fieldset>
            <legend>Czy wystawisz recenzje:</legend>
            <div class="col-xs-2 col-md-2">
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#odrzuc">
                    Odrzuć
                </button>

            </div>
            <div class="col-xs-2 col-md-2">
                <?php echo Form::model($id,['route'=>['recenzent.akceptuj',$id],'method'=>'PUT']); ?>

                <?php echo Form::submit('Akceptuj',['class'=>'btn btn-success','onClick'=>'return sprawdz()']); ?>

                <?php echo Form::close(); ?>

            </div>
        </fieldset>
        <div id="odrzuc" class="modal fade" role="dialog">
            <div class="modal-dialog">
            <?php echo Form::model($id,['route'=>['recenzent.odrzuc',$id],'method'=>'PUT']); ?>

            <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title">Odrzuć</h3>
                    </div>
                    <div class="modal-body">
                        <h4>Czy na pewno nie chcesz wyznaczać recenzji?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>
                        <?php echo Form::submit('Odrzuć',['class'=>'btn btn-danger','onClick'=>'return sprawdz()']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>


<?php endif; ?>


    <?php if($id->status==2): ?>
        <div class="tekst"> Dodaj opinie przez: </div>
        <ul class="nav nav-tabs">

            <li class="active"><a href="#formularz">Formularz</a></li>
            <li><a href="<?php echo e(route('recenzent.createPlik',$page)); ?>">Plik</a></li>

        </ul>


    <div id="formularz" class="tab">
        <?php echo Form::open(['route'=>['recenzent.storeFormularz',$id]]); ?>

        <?php echo Form::hidden('recenzja_id',$id->id); ?>

        <div class="form-group <?php echo e($errors->has('confidence') ? 'has-error' : ''); ?>">
            <?php echo Form::label('confidence','Confidence:'); ?><br>
            <input type="radio" name="confidence" value="Very confidence"> Very confidence
            <input type="radio" name="confidence" value="Quite confidence"> Quite confidence
            <input type="radio" name="confidence" value="Not very confidence"> Not very confidence
            <?php if($errors->has('confidence')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('confidence')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('decision') ? ' has-error' : ''); ?>" >
            <?php echo Form::label('decision','The decision:'); ?><br>
            <input type="radio" name="decision" value="accept as is (editorial changes only, can be done by the editor)"> accept as is (editorial changes only, can be done by the editor)<br>
            <input type="radio" name="decision" value="accept, requires changes by the author to be approved by the editor">  accept, requires changes by the author to be approved by the editor<br>
            <input type="radio" name="decision" value="reject, substantial author's revisions needed before resubmission for another review"> reject, substantial author's revisions needed before resubmission for another review<br>
            <input type="radio" name="decision" value="decision delayed, MML revision needed"> decision delayed, MML revision needed<br>
            <input type="radio" name="decision" value="reject, no hope of getting anything of value"> reject, no hope of getting anything of value<br>
            <?php if($errors->has('decision')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('decision')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('presentation') ? ' has-error' : ''); ?>">
            <?php echo Form::label('presentation','Presentation:'); ?><br>
            <input type="radio" name="presentation" value="very poor"> Very poor
            <input type="radio" name="presentation" value="poor"> Poor
            <input type="radio" name="presentation" value="good"> Good
            <input type="radio" name="presentation" value="very good"> Very good
            <?php if($errors->has('presentation')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('presentation')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('quality_of_formalization') ? ' has-error' : ''); ?>">
            <?php echo Form::label('quality_of_formalization','The quality of formalization:'); ?><br>
            <input type="radio" name="quality_of_formalization" value="very poor"> Very poor
            <input type="radio" name="quality_of_formalization" value="poor"> Poor
            <input type="radio" name="quality_of_formalization" value="good"> Good
            <input type="radio" name="quality_of_formalization" value="very good"> Very good
            <?php if($errors->has('quality_of_formalization')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('quality_of_formalization')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('significance_for_mml') ? ' has-error' : ''); ?>">
            <?php echo Form::label('significance_for_mml','Significance for MML:'); ?><br>
            <input type="radio" name="significance_for_mml" value="very poor"> Very poor
            <input type="radio" name="significance_for_mml" value="poor"> Poor
            <input type="radio" name="significance_for_mml" value="good"> Good
            <input type="radio" name="significance_for_mml" value="very good"> Very good
            <?php if($errors->has('significance_for_mml')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('significance_for_mml')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('comments') ? ' has-error' : ''); ?>">
            <?php echo Form::label('comments',"Justification/comments (to be forwarded to the authors):"); ?>

            <?php echo Form::textarea('comments',null,['class'=>'form-control']); ?>

            <?php if($errors->has('comments')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('comments')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('comments_editors') ? ' has-error' : ''); ?>">
            <?php echo Form::label('comments_editors',"Comments to editors only:"); ?>

            <?php echo Form::textarea('comments_editors',null,['class'=>'form-control']); ?>

            <?php if($errors->has('comments_editors')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('comments_editors')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group <?php echo e($errors->has('mml_remarks') ? ' has-error' : ''); ?>">
            <?php echo Form::label('mml_remarks',"MML Remarks:"); ?>

            <?php echo Form::textarea('mml_remarks',null,['class'=>'form-control']); ?>

            <?php if($errors->has('mml_remarks')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('mml_remarks')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary','onClick'=>'return sprawdz()']); ?>

            <?php echo link_to(URL::previous(),'Powrót',['class'=>'btn btn-default']); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>


<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.recenzent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>