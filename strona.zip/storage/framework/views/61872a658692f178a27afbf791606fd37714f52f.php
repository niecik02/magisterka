<?php $__env->startSection('content'); ?>
    <h1>Zmieniono date oddania recenzji </h1>

    <h3>Tytuł pracy:<?php echo e($page->title); ?></h3>
    <h4>Nowy termin oddania recenzji: <?php echo e($request->data); ?> </h4>


    Wiadomość generowana automatycznie prosimy na nią nieodpowiadac!!!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>