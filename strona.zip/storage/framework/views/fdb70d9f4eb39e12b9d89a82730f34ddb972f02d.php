<?php $__env->startSection('title', 'Edycja'); ?>
<?php $__env->startSection('content'); ?>
    <div class="naglowek">Tytuł</div><div class="tekst"><?php echo e($page->title); ?></div>
    <div class="naglowek"> Autorzy:</div>
    <div class="tekst"><?php $__currentLoopData = $autorzy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($autor->name); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="naglowek"> Pliki:</div>
    <?php if(isset($page->plik_miz)): ?>
        <a class="pobierz" href= <?php echo e(asset($page->plik_miz)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik miz</span> </a><br/>

        <a class="pobierz" href= <?php echo e(asset($page->plik_bib)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik bib</span> </a><br/>
        <?php if(isset($page->plik_voc)): ?>
            <a class="pobierz" href= <?php echo e(asset($page->plik_voc)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik voc</span></a><br/>
        <?php endif; ?>
    <?php else: ?>
        <div class="tekst">Brak plików do pobrania</div>
    <?php endif; ?>
    <?php if($komentarze!='[]'): ?>
        <div class="tekst">
            <div class="panel panel-primary">
                <div class="panel-heading" role="tab" id="headingOne">
                    <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#wiadomości" aria-expanded="false" aria-controls="wiadomości">
                        <h4 class="panel-title">
                            Wiadomości <span class="caret"></span>
                        </h4>
                    </a>
                </div>
                <div id="wiadomości" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <?php $__currentLoopData = $komentarze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentarz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="panel-body">
                            <div class="naglowek">
                                <?php if($komentarz->status==2): ?>
                                    <span class="glyphicon glyphicon-user">
                                    Edytor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php else: ?>
                                    <span class="glyphicon glyphicon-user">
                                    Autor:
                                </span>
                                    <?php echo e($komentarz->komentarz); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php echo Form::model($page,['route'=>['hello.zmienDate',$page],'method'=>'PUT']); ?>


    <div class="row">
        <div class='col-sm-6'>
            <div class="form-group <?php echo e($errors->has('data') ? ' has-error' : ''); ?>">
                <?php echo Form::label('data','Zmień date oddania recenzjii'); ?>

                <div class='input-group date' id='datetimepicker1'>
                    <?php echo Form::date('data',$data->data,['class'=>"form-control",'required'=>"true"]); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <?php if($errors->has('data')): ?>
                    <span class="help-block">
                                        <strong><?php echo e($errors->first('data')); ?></strong>
                                    </span>
                <?php endif; ?>
            </div>
        </div>

    </div>


    <div class="row">
        <div class="form-group">
            <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary','onClick'=>'sprawdz()']); ?>

            <?php echo link_to(URL::previous(),'Powrót',['class'=>'btn btn-default']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.edytor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>