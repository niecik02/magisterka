    <?php $__env->startSection('title', 'Edycja'); ?>
    <?php $__env->startSection('content'); ?>
        <div class="naglowek">Tytuł</div><div class="tekst"><?php echo e($page->title); ?></div>
        <div class="naglowek"> Autorzy:</div>
        <div class="tekst"><?php $__currentLoopData = $autorzy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($autor->name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="naglowek"> Pliki:</div>
        <?php if(isset($page->plik_miz)): ?>
            <a class="pobierz" href= <?php echo e(asset($page->plik_miz)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik miz</span> </a><br/>

            <a class="pobierz" href= <?php echo e(asset($page->plik_bib)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik bib</span> </a><br/>
            <?php if(isset($page->plik_voc)): ?>
                <a class="pobierz" href= <?php echo e(asset($page->plik_voc)); ?>><span class="glyphicon glyphicon-download"></span><span>Pobierz plik voc</span></a><br/>
            <?php endif; ?>
        <?php else: ?>
            <div class="tekst">Brak plików do pobrania</div>
        <?php endif; ?>
        <?php if($komentarze!='[]'): ?>
            <div class="tekst">
                <div class="panel panel-primary">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <a class="pusta" data-toggle="collapse" data-parent="#accordion" href="#wiadomości" aria-expanded="false" aria-controls="wiadomości">
                            <h4 class="panel-title">
                                Wiadomości <span class="caret"></span>
                            </h4>
                        </a>
                    </div>
                    <div id="wiadomości" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <?php $__currentLoopData = $komentarze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentarz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="panel-body">
                                <div class="naglowek">
                                    <?php if($komentarz->status==2): ?>
                                        <span class="glyphicon glyphicon-user">
                                    Edytor:
                                </span>
                                        <?php echo e($komentarz->komentarz); ?>

                                    <?php else: ?>
                                        <span class="glyphicon glyphicon-user">
                                    Autor:
                                </span>
                                        <?php echo e($komentarz->komentarz); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<?php if($recenzenci=='[]'): ?>
        <?php echo Form::open(['route'=>['hello.store',$page]]); ?>


        <div class="row">
            <div class='col-sm-3 col-xs-3 col-md-3'>
                <div class="form-group <?php echo e($errors->has('data') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('data','Wyznacz date oddania recenzji:'); ?>

                    <div class='input-group date' id='datetimepicker1'>
                        <?php echo Form::date('data',$data,['class'=>"form-control",'required'=>"true"]); ?>

                        <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>

                    </div>
                    <?php if($errors->has('data')): ?>
                        <span class="help-block">
                                        <strong><?php echo e($errors->first('data')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <?php echo Form::label('users_id[]', 'Dodaj Recenzentów:'); ?>

            </div>
        </div>


        <div class="row dodaj_form">
            <div class="col-xs-5 col-md-5 col-sm-5">
                <div class="input-group">
                    <div class="input-group-addon "><span class="glyphicon glyphicon-list"> </span></div>
                    <?php echo Form::select('users_id[]', $users ,null,['class'=>"form-control select",'id'=>'users_id','required'=>'required','placeholder'=>'Wybierz ...','data-live-search'=>"true"]); ?>

                </div>
                <div class="error"></div>
            </div>
            <div class="col-xs-4 col-md-4 col-sm-4">
                <button type="button" class="btn btn-danger usun"  onclick='usun_autora(this)'>
                    <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> Usuń
                </button>
                <button type="button" class="btn btn-info dodaj" onclick='dodaj_autora(this)'>
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj
                </button>
            </div>
        </div>

        <div class="row dodaj_form">
            <div class="col-xs-5 col-md-5">
                <div class="input-group">
                    <div class="input-group-addon "><span class="glyphicon glyphicon-list"> </span></div>
                    <?php echo Form::select('users_id[]', $users ,null,['class'=>"form-control select",'id'=>'users_id','required'=>'required','placeholder'=>'Wybierz ...','data-live-search'=>"true"]); ?>

                </div>
                <div class="error"></div>
            </div>
            <div class="col-xs-4 col-md-4">
                <button type="button" class="btn btn-danger usun"  onclick='usun_autora(this)'>
                    <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> Usuń
                </button>
                <button type="button" class="btn btn-info dodaj" onclick='dodaj_autora(this)'>
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Dodaj
                </button>
            </div>
        </div>
        <div class="form-group">
            <?php echo Form::button('Dodaj nowego użytkownika',['class'=>'btn btn-primary loading','data-toggle'=>"modal", 'data-target'=>'#dodajUser']); ?>

        </div>

            <div class="row form-group">
                <div class="col-xs-10 col-md-10">
                    <div class="navbar-left">
                    <?php echo link_to(URL::previous(),'Powrót',['class'=>'btn btn-default']); ?>

                    <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary loading','data-loading-text'=>"Zapisuje",'id'=>'przycisk','onClick'=>'return akceptuj()']); ?>

                    <?php echo Form::close(); ?>

                    </div>
                    <div class="navbar-right">
                        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#dopoprawy">
                            Popraw
                        </button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#odrzuc">
                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                            Odrzuć
                        </button>
                    </div>
                </div>
            </div>


<?php else: ?>
    <?php echo Form::open(['route'=>['hello.ponow',$page]]); ?>

    <div class="row">
        <div class='col-sm-6'>
            <div class="form-group <?php echo e($errors->has('data') ? ' has-error' : ''); ?>">
                <?php echo Form::label('data','Wyznacz date oddania recenzjii'); ?>

                <div class='input-group date' id='datetimepicker1'>
                    <?php echo Form::date('data',$data,['class'=>"form-control",'required'=>"true"]); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <?php if($errors->has('data')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('data')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

    <div class="col-sm-12 col-md-12">
        <?php echo Form::label('users_id[]', 'Wyślij do tych samych recenzentów:'); ?>

    </div>
    <?php $__currentLoopData = $recenzenci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($recenzent->status!=3): ?>

        <div class="col-xs-12 col-md-12">
            <div class="row dodaj_form">
                <div class="col-xs-8 col-md-8">
                    <div class="input-group">
                        <div class="input-group-addon "><span class="glyphicon glyphicon-list"> </span></div>
                        <?php echo Form::select('users_id[]', $users ,$recenzent->users_id,['class'=>'form-control select','id'=>'users_id','placeholder'=>'Wybierz...','required'=>'required']); ?>

                    </div>
                    <div class="error"></div>
                </div>
                <div class="col-xs-4 col-md-4">
                    <button type="button" class="btn btn-danger usun"  onclick='usun_autora(this)'>
                        <span class="glyphicon glyphicon-minus" aria-hidden="true"></span>
                    </button>
                    <button type="button" class="btn btn-info dodaj" onclick='dodaj_autora(this)'>
                        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <div class="col-xs-10 col-md-10">
                <div class="navbar-left">
                    <?php echo link_to(URL::previous(),'Powrót',['class'=>'btn btn-default']); ?>

                    <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary loading','data-loading-text'=>"Zapisuje",'id'=>'przycisk', 'onClick'=>'return sprawdz()']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="navbar-right">
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#dopoprawy">
                        Popraw
                    </button>
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#odrzuc">
                        <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                        Odrzuć
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


        <div id="dodajUser" class="modal fade"  tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Dodawanie nowego użytkownika</h4>
                    </div>
                        <div class="modal-body">
                            <form class="form-horizontal" role="form">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group" id="name" >
                                <label for="name" class="col-md-4 control-label">Imie i Nazwisko</label>
                                <div class="col-md-6">
                                    <input type="text" id="name_dane" class="form-control" name="name" required autofocus>
                                    <div class="error"></div>
                                </div>
                            </div>
                            <div class="form-group" id="email">
                                <label for="email" class="col-md-4 control-label">E-Mail </label>
                                <div class="col-md-6">
                                    <input  type="email"id="email_dane" class="form-control" name="email"  required>
                                    <div class="error"></div>
                                </div>
                            </div>
                            </form>
                        </div>
                        <div class="modal-footer ">
                            <button type="button" class="btn btn-default" onClick='wyczysc_pola()' data-dismiss="modal" >Anuluj</button>
                            <button type="submit" class="btn btn-primary" onClick='sprawdz()' id="rejestracja">
                                Rejestracja
                            </button>
                        </div>
                </div>
            </div>
        </div>


        <div id="dopoprawy" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <?php echo Form::model($page,['route'=>['hello.poprawa',$page],'method'=>'PUT','onSubmit'=>"return sprawdz_form(this)"]); ?>

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Do poprawy</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                                <?php echo Form::label('komentarz',"Komentarz:"); ?>

                                <?php echo Form::textarea('komentarz',null,['class'=>'form-control', 'placeholder'=>'Dodaj komentarz...','required','id'=>'komentarz']); ?>

                            <div class="error"></div>
                        </div>
                    </div>
                    <div class="modal-footer ">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>
                        <?php echo Form::submit('Do poprawy',['class'=>'btn btn-warning']); ?>

                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>






        <div id="odrzuc" class="modal fade" role="dialog">
            <div class="modal-dialog">
            <?php echo Form::model($page,['route'=>['hello.odrzuc',$page],'method'=>'PUT','onSubmit'=>"return sprawdz_form(this)"]); ?>

            <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Czy napewno odrzucić artykuł?</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php echo Form::label('komentarz',"Komentarz:"); ?>

                            <?php echo Form::textarea('komentarz',null,['class'=>'form-control', 'placeholder'=>'Dodaj komentarz...','required','id'=>'komentarz']); ?>

                            <div class="error"></div>
                        </div>
                    </div>
                    <div class="modal-footer ">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>
                        <button type="submit" class='btn btn-danger'>
                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                            Odrzuć
                        </button>

                    </div>
                </div>
                <?php echo Form::close(); ?>


            </div>
        </div>


        <script src="<?php echo e(asset('js/dodajUser.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.edytor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>