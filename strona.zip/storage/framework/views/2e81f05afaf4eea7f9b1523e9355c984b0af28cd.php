<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> <?php echo $__env->yieldContent('title'); ?> </title>


    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">



    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/mojestyle.css')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">




    <script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>



</head>
<body>
<?php echo $__env->make('sweetalert::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="app">
    <nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                </button>

                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Główna
                </a>
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav navbar-header">
                    <?php if(auth()->guard()->guest()): ?>
                    &nbsp;
                    <?php else: ?>

                        <?php echo $__env->yieldContent('nav'); ?>

                        <?php endif; ?>

                </ul>


                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->

                    <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-log-in"></span> Zaloguj</a></li>
                    <li><a href="<?php echo e(route('register')); ?>"><span class="glyphicon glyphicon-user"></span> Rejestracja</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <span class="glyphicon glyphicon-user">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </span>
                            </a>

                            <ul class="dropdown-menu">
                                <li>
                                    <a href="<?php echo e(route('uzytkownik.zmiendane')); ?>">
                                        Edytuj
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Wyloguj
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>

                </ul>
            </div>
        </div>
    </nav>



    <div class="container">
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>


    <footer class="panel-footer navbar-fixed-bottom">
        &copy Praca Magisterska- Robert Niecikowski
    </footer>
</div>
<div id="loading">

</div>


<script src="<?php echo e(asset('js/moj.js')); ?>"></script>


</body>
</html>
