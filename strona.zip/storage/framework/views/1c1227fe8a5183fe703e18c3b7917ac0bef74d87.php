<?php $__env->startSection('title', 'Dodawanie'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Dodaj Artykuł</h2>


    <?php echo Form::open(['route'=>'autor.uploadfile','method'=>'POST', 'files'=>true]); ?>


    <?php if($errors->any()): ?>


        <?php echo e(Session::forget('_old_input.users_id')); ?>


        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="btn btn-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php endif; ?>

    <div class="row">
        <div class="col-sm-12 col-md-5">
            <div class="form-group">

                 <?php echo Form::label('title',"Tytuł:"); ?>

                    <div class="input-group">
                        <div class="input-group-addon"><span class="glyphicon glyphicon-text-width"> </span></div>

                        <?php echo Form::text('title',null,['class'=>'form-control', 'placeholder'=>'Dodaj Tytuł']); ?>

                    </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-4">
            <?php echo Form::label ('plik_miz','Wybierz plik .miz do wyslania'); ?>

            <?php echo Form::file('plik_miz'); ?>

        </div>

        <div class="col-sm-12 col-md-4">
            <?php echo Form::label ('plik_bib','Wybierz plik .bib do wyslania'); ?>

            <?php echo Form::file('plik_bib'); ?>


        </div>
        <div class="col-sm-12 col-md-4">
            <?php echo Form::label ('plik_voc','Wybierz plik .voc do wyslania(opcjonalne)'); ?>

            <?php echo Form::file('plik_voc'); ?>


        </div>

    </div>
    <br/>
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body alert-success">
                    <p>Czy kontynuować dodawanie pracy?</p>
                </div>
                <div class="modal-footer ">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>
                    <?php echo Form::submit('Kontynuuj',['class'=>'btn btn-primary loading','id'=>'przycisk','onClick'=>'return sprawdz()']); ?>

                </div>
            </div>

        </div>
    </div>
    <div class="form-group">
        <?php echo Form::submit('Zapisz',['class'=>'btn btn-primary loading','id'=>'przycisk','onClick'=>'return akceptuj_dodanie()']); ?>

        <?php echo link_to(URL::previous(),'Powrót',['class'=>'btn btn-default']); ?>

        <?php echo Form::close(); ?>

    </div>




    <script src="<?php echo e(asset('js/moj.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>