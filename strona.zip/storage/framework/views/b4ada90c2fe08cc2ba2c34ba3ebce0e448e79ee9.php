<?php $__env->startSection('title', 'Autor'); ?>
<?php $__env->startSection('content'); ?>

<h1>Moje Artykuły</h1>

<?php echo Form::text('szukaj',null,['placeholder'=>'wpisz tytuł','id'=>'szukaj','class'=>'form-control']); ?>

<table  class="table table-hover">
    <thead>
        <tr>
            <th>Tytuł</th>
            <th>Status</th>
            <th>Data dodania</th>
            <th>Opcje</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><a class="text" href="<?php echo e(route('autor.show',$page->id)); ?>"><?php echo e($page->title); ?></a></th>
                <th>
                    <?php $__currentLoopData = $statusy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($status->id==$page->status): ?>
                            <?php echo e($status->status); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </th>
                <th><?php echo e($page->created_at); ?></th>
                <th>
                    <?php if($page->status==6): ?>
                        <a href="<?php echo e(route('autor.edit',$page)); ?>">
                            <button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="Edytuj">
                            <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                        </button>
                        </a>
                    <?php endif; ?>
                </th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>




<script type="text/javascript" src=<?php echo e(asset("js/paginathing.js")); ?>></script>
    <script>
        var $rows = $('.table tbody tr');
        $('#szukaj').keyup(function() {

            var val = '^(?=.*\\b' + $.trim($(this).val()).split(/\s+/).join('\\b)(?=.*\\b') + ').*$',
                reg = RegExp(val, 'i'),
                text;

            $rows.show().filter(function() {
                text = $(this).text().replace(/\s+/g, ' ');
                return !reg.test(text);
            }).hide();
        });



        jQuery(document).ready(function($){

            $('.table tbody').paginathing({
                perPage: 10,
                insertAfter: '.table',

            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>