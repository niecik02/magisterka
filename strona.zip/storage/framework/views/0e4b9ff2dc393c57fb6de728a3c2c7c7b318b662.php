<?php $__env->startSection('title','Statystyki'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::open(['route'=>'hello.statystyka','method'=>'GET']); ?>

        <div class="row">
            <div class='col-sm-3'>
                <div class="form-group">
                    <?php echo Form::label('data_pocz','Od kiedy:'); ?>

                    <div class='input-group date'>
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                        <?php echo Form::date('data_pocz','2018-04-30',['class'=>"form-control",'required'=>"true"]); ?>

                    </div>
                </div>
            </div>
            <div class='col-sm-3'>
                <div class="form-group">
                    <?php echo Form::label('data_kon','Do kiedy:'); ?>

                    <div class='input-group date'>
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                        <?php echo Form::date('data_kon',date('Y-m-d'),['class'=>"form-control",'required'=>"true"]); ?>

                    </div>
                </div>
            </div>
            <div class='col-sm-3'>
                <div class="form-group">
                    <?php echo Form::label('szukaj','Szukaj:'); ?>

                    <div class='input-group'>
                        <div class="input-group-addon"><span class="glyphicon glyphicon-list"></span></div>
                        <?php echo Form::select('szukaj',[1=>'Akceptowanych artykułów',2=>'Wystawionych recenzji',3=>'Odrzuconych artykułów',4=>'Odrzuconych recenzji',5=>'Wszystkie Artykuły'],null,['class'=>"form-control ",'required'=>"true"]); ?>

                    </div>
                </div>
            </div>
            <div class='col-sm-3 navbar-right'>
                <div class="form-group">
                    <?php echo Form::submit('Filtruj',['class'=>'btn btn-block','style'=>'margin-top:27px;']); ?>

                </div>
            </div>
            <div class='col-sm-2'>
                <div class="form-group">
                    <?php echo Form::label('ilosc','Na stronie :'); ?>

                    <div class='input-group'>
                        <div class="input-group-addon"><span class="glyphicon glyphicon-eye-open"></span></div>
                        <?php echo Form::select('ilosc',[5=>'5',10=>'10',25=>'25',50=>'50'],null,['class'=>"form-control ",'required'=>"true"]); ?>

                    </div>
                </div>
            </div>
            <div class='col-sm-2'>
                <div class="form-group">
                    <?php echo Form::label('sortuj','Sortuj :'); ?>

                    <div class='input-group'>
                        <div class="input-group-addon"><span class="glyphicon glyphicon-eye-open"></span></div>
                        <?php echo Form::select('sortuj',['DESC'=>'Malejąco','ASC'=>'Rosnąco'],null,['class'=>"form-control ",'required'=>"true"]); ?>

                    </div>
                </div>
            </div>

        </div>
    <?php echo Form::close(); ?>



    <div class="row">
        <div class="col-sm-12">
            <table class="table table-striped" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th>
                            Użytkownik
                        </th>
                        <th>
                            Ilość
                        </th>

                        <th width="33%" >
                            Procent wszystkich
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dane; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <?php $__currentLoopData = $dane2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dana2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($dana->id==$dana2->id): ?>
                                    <td><?php echo e($dana->name); ?></td>
                                    <td><?php echo e($dana->ilosc); ?></td>

                                    <td width="33%"><?php echo e(round($dana->ilosc/$dana2->wszystkie*100,2)); ?>%</td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="text-center"> Brak danych</td></tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Wszystkie:</th><th><?php echo e($szukane); ?></th><th width="33%" ><?php echo e(round($szukane/$wszystko*100,2)); ?>%</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.edytor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>